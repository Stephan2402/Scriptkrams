﻿############################################################################
###
### Veeam Backup and Replication Reporting
###
### Please send your questions or concerns to stephan.verstegen@bechtle.com
###
############################################################################
### USAGE
###
###
############################################################################
### CHANGELOG
###
### version 1.3 (stephan.verstegen@bechtle.com):
### * Customize PDF Export
###
### version 1.2 (stephan.verstegen@bechtle.com):
### * Adding PDF Export
###
### version 1.1 (stephan.verstegen@bechtle.com):
### * Adding Folder creation
### * Adding "TB" in HTML Table
###
### version 1.0 (stephan.verstegen@bechtle.com):
### * initial release
###
############################################################################
### DO NOT CHANGE ANYTHING BELOW THIS LINE
### BEGIN SIGN
############################################################################
$MyPath = "C:\Reports\Script\Verstegen"
#Load PSSnap-IN
If (-not (Get-PSSnapin VeeamPSSnapin -ErrorAction SilentlyContinue))
{
    try 
    { 
        Add-PSSnapin VeeamPSSnapin -ErrorAction Stop 
    }
    catch 
    { 
        Write-Host "Veeam Backup PowerShell Snap-In is not installed, please follow steps outlined at http://www.veeam.com/kb1489" -ForegroundColor Red
        Exit
    }
}
# Get infos from Veeam Cloud Connect
If ((Get-VBRCloudTenant -ErrorAction SilentlyContinue))
{
    try
    {
        $VeeamTenants = Get-VBRCloudTenant -ErrorAction Stop
    }
    catch
    {
        Write-Host "There are no Cloud Tenants available!" -ForegroundColor Red
        Exit
    }
}
# Load PDF Module
If (-not (Get-Module PDF-2 -ErrorAction SilentlyContinue))
{
    try 
    { 
        Add-Type -Path “$MyPath\bin\itextsharp.dll”
        Import-Module $MyPath\PDF-2.psm1  -ErrorAction Stop 
    }
    catch 
    { 
        Write-Host "PDF Function could not be loaded" -ForegroundColor Red
        Exit
    }
}
#Create folder by date
$date = Get-Date
$date = $date.ToString("yyyy-MM-dd")
$month = Get-Date -Format y
$NewFolder = New-Item -ItemType directory -Path "$MyPath\$date"
$MyPath = $MyPath + "\" + $date
#Generate HTML Report
foreach ($array in $VeeamTenants)
{
    $TenantReport = Get-VBRCloudTenant -Name $array
    $TenantName = $TenantReport.Name
    $TenantVMCount = $TenantReport.VmCount
    $TenantUsedSpaceTB = $TenantReport.Resources.usedspace/1MB
    $TenantQuotaTB = $TenantReport.Resources.repositoryQUota/1MB
    $TenantFreeSpaceTB = $TenantQuotaTB - $TenantUsedSpaceTB
    $TenantUsedSpaceTB = ($TenantUsedSpaceTB).ToString("00.00")
    $TenantQuotaTB = ($TenantQuotaTB).ToString("00.00")
    $TenantFreeSpaceTB = ($TenantFreeSpaceTB).ToString("00.00")

    $HTMLBody = 
    "
    <p style='font-family: Tahoma; font-size: 18px; padding-top: 5px; padding-bottom:5px;'>Report $TenantName vom $month</p>
    <table cellspacing='0' cellpadding='0' width='100%' border='0' style='border-collapse: collapse;'>
      <tr style='background-color: #a7a7a7; font-weight:bold;height: 17px;'>
        <td style='font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>
              Customer
            </td>
        <td style='font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>
              Number of VM
            </td>
        <td style='font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>
              Total quota
            </td>
        <td style='font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>
              Used space
            </td>
        <td style='font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>
              Free space
            </td>
      </tr>
      <tr style='height: 17px;background-color: #ffffff;'>
        <td style='width:150px;font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>$TenantName</td>
        <td style='width:150px;font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>$TenantVMCount</td>
        <td style='width:200px;font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>$TenantQuotaTB TB</td>
        <td style='width:200px;font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>$TenantUsedSpaceTB TB</td>
        <td style='width:85px;font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>$TenantFreeSpaceTB TB</td>
      </tr>
    </table>
    "
    
    #Create HTML File
    ConvertTo-Html -Title "Report Tenant $TenantName" -Body $HTMLBody | Set-Content "$MyPath\$TenantName.html"

    #Generate PDF Report
    $pdf = New-Object iTextSharp.text.Document
    Create-PDF -Document $pdf -File "$MyPath\$TenantName.pdf" -TopMargin 20 -BottomMargin 20 -LeftMargin 20 -RightMargin 20 -Author "Bechtle Münster GmbH & Co. KG"
    $pdf.Open()
    Add-Image -Document $pdf -File "$PSScriptRoot\bin\BechtleLogo.png"
    Add-Text -Document $pdf -Text " "
    Add-Title -Document $pdf -Text "Auswertung $TenantName vom $month" -Color "Black" -Centered
    Add-Text -Document $pdf -Text "Test Text! Hier Kann noch irgendwas stehen ... :)"
    Add-Table -Document $pdf -Dataset @("Customer", "Number of VM", "Total Quota", "Used Space", "Free Space", "$TenantName", "$TenantVMCount", "$TenantQuotaTB TB", "$TenantUsedSpaceTB TB", "$TenantFreeSpaceTB TB") -Cols 5 -Centered
    #Add-Image -Document $pdf -File "$PSScriptRoot\kitten2.jpg"
    #Add-Table -Document $pdf -Dataset @("Name", "Achilles", "Age", "2", "Fur color", "Grey", "Favorite toy", "Shoes") -Cols 2 -Centered
    Add-Text -Document $pdf -Text "Test Text! Hier Kann noch irgendwas stehen ... :)"
    $pdf.Close()
}


############################################################################
### END SIGN
### DO NOT CHANGE ANYTHING ABOVE THIS LINE
############################################################################