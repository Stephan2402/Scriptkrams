﻿############################################################################
###
### Veeam Backup and Replication Reporting
###
### Please send your questions or concerns to stephan.verstegen@bechtle.com
###
############################################################################
### USAGE
###
###
############################################################################
### CHANGELOG
###
### version 1.1 (stephan.verstegen@bechtle.com):
### * Adding Folder creation
### * Adding "TB" in HTML Table
###
### version 1.0 (stephan.verstegen@bechtle.com):
### * initial release
###
############################################################################
### DO NOT CHANGE ANYTHING BELOW THIS LINE
### BEGIN SIGN
############################################################################
$Path = "C:\Reports\Script\Verstegen"
#Load PSSnap-IN
If (-not (Get-PSSnapin VeeamPSSnapin -ErrorAction SilentlyContinue))
{
    try 
    { 
        Add-PSSnapin VeeamPSSnapin -ErrorAction Stop 
    }
    catch 
    { 
        Write-Host "Veeam Backup PowerShell Snap-In is not installed, please follow steps outlined at http://www.veeam.com/kb1489" -ForegroundColor Red
        Exit
    }
}
# Get infos from Veeam Cloud Connect
If ((Get-VBRCloudTenant -ErrorAction SilentlyContinue))
{
    try
    {
        $VeeamTenants = Get-VBRCloudTenant -ErrorAction Stop
    }
    catch
    {
        Write-Host "There are no Cloud Tenants available!" -ForegroundColor Red
        Exit
    }
}
#Create folder by date
$date = Get-Date
$date = $date.ToString("yyyy-MM-dd")
$month = Get-Date -Format y
$NewFolder = New-Item -ItemType directory -Path "$Path\$date"
$Path = $Path + "\" + $date
#Generate Report
foreach ($array in $VeeamTenants)
{
    $TenantReport = Get-VBRCloudTenant -Name $array
    $TenantName = $TenantReport.Name
    $TenantVMCount = $TenantReport.VmCount
    $TenantUsedSpaceTB = $TenantReport.Resources.usedspace/1MB
    $TenantQuotaTB = $TenantReport.Resources.repositoryQUota/1MB
    $TenantFreeSpaceTB = $TenantQuotaTB - $TenantUsedSpaceTB
    $TenantUsedSpaceTB = ($TenantUsedSpaceTB).ToString("00.00")
    $TenantQuotaTB = ($TenantQuotaTB).ToString("00.00")
    $TenantFreeSpaceTB = ($TenantFreeSpaceTB).ToString("00.00")

    $HTMLBody = 
    "
    <p style='font-family: Tahoma; font-size: 18px; padding-top: 5px; padding-bottom:5px;'>Report $TenantName vom $month</p>
    <table cellspacing='0' cellpadding='0' width='100%' border='0' style='border-collapse: collapse;'>
      <tr style='background-color: #a7a7a7; font-weight:bold;height: 17px;'>
        <td style='font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>
              Customer
            </td>
        <td style='font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>
              Number of VM
            </td>
        <td style='font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>
              Total quota
            </td>
        <td style='font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>
              Used space
            </td>
        <td style='font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>
              Free space
            </td>
      </tr>
      <tr style='height: 17px;background-color: #ffffff;'>
        <td style='width:150px;font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>$TenantName</td>
        <td style='width:150px;font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>$TenantVMCount</td>
        <td style='width:200px;font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>$TenantQuotaTB TB</td>
        <td style='width:200px;font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>$TenantUsedSpaceTB TB</td>
        <td style='width:85px;font-family: Tahoma; font-size: 12px; white-space:nowrap; border:1px solid #a7a7a7; padding:2px;'>$TenantFreeSpaceTB TB</td>
      </tr>
    </table>
    "
    
    #Create HTML File
    ConvertTo-Html -Title "Report Tenant $TenantName" -Body $HTMLBody | Set-Content "$Path\$TenantName.html"
}

############################################################################
### END SIGN
### DO NOT CHANGE ANYTHING ABOVE THIS LINE
############################################################################